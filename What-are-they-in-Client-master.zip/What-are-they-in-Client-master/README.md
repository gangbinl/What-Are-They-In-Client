# What Are They In - Client side

## Disclamer
This is early work in progress with a lot of changes expected, including this README file.

## Introduction

This is the client side code base. 
It is build over using Xcode and Swift.
More to be added later in development to this section.

## Requirements

 * Latest version of Xcode
 * Latest version of Xcode command line tools.

## Setup
* git clone
* Press run or Command(⌘) + R

## Testing
Currently testing is something the team is looking into as it provdes some challenges.

